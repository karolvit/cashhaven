const theme = {
  colors: {
    primary: "#712976",
    secondary: "#c89cff",
    textPricipal: "#000000",
    textSideBar: "#FFFFFF",
  },
  fonts: {
    primary: "'Inter', sans-serif",
  },
};
export default theme;
