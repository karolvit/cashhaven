const PagamentoPedido = () => {
  return <div>PagamentoPedido</div>;
};

export default PagamentoPedido;
